# Capital Gains Automation — Setup Guide for CA

This runs **entirely on your laptop**. No cloud, no API keys. Files never leave your machine.

---

## What's in the package

| File | Purpose |
|---|---|
| `capital_gains_extractor.py` | Core engine — parses 30+ broker formats |
| `server.py` | Local web server (port 5000) |
| `capital_gains_portal.html` | Browser UI — drop files here |
| `requirements.txt` | Python dependencies |
| `README_FOR_CA.md` | This file |

---

## One-time setup (15 minutes)

### 1. Install Python 3.10+
Already on most laptops. Check: open Terminal and run `python3 --version`.

### 2. Install Ollama (the AI fallback)
This is what handles **new broker formats** the system hasn't seen before.

- Download: https://ollama.com/download
- Install it (just click through)
- Open Terminal and pull the model:
  ```
  ollama pull llama3.1:8b
  ```
  (This is a one-time ~5 GB download. Takes 10–20 min on decent internet.)

- Verify Ollama is running:
  ```
  ollama list
  ```
  You should see `llama3.1:8b` in the list.

### 3. Install Python dependencies
In Terminal, navigate to this folder and run:
```
pip3 install -r requirements.txt
```

---

## Running the system (every time you want to process files)

### Step 1 — Start Ollama (if not already running)
Ollama usually auto-starts. To confirm, run:
```
ollama serve
```
Leave this Terminal window open. (Or skip — Ollama runs as a background service after install on Mac/Windows.)

### Step 2 — Start the server
Open a **new** Terminal in this folder and run:
```
python3 server.py
```
You'll see: `Running on http://0.0.0.0:5000` — leave this window open.

### Step 3 — Open the portal
Double-click `capital_gains_portal.html` — it opens in your browser.
Drop the broker statements in. Click "Process Statements". Download the Excel.

That's it.

---

## How it handles new broker formats

The system has 30+ specialist parsers (CAMS, Zerodha, Upstox, Nirmal Bang, HDFC, Motilal Oswal, etc.).

When a new format arrives that no parser recognises:
1. The system tries the closest-matching parser
2. If that returns 0 rows → it falls back to **local Ollama**
3. Ollama reads the file page-by-page and extracts transactions as JSON
4. Results are deduplicated and merged into the output

So even formats we've never seen before will work — they'll just take a bit longer (Ollama ~30–90 seconds per file vs ~1 second for known formats).

---

## Configuration (optional)

Set these environment variables before running `server.py` if you need to:

- `OLLAMA_URL` (default `http://localhost:11434`) — change if Ollama runs elsewhere
- `OLLAMA_MODEL` (default `llama3.1:8b`) — try `llama3.1:70b` for higher accuracy on tricky formats (needs ~40 GB RAM) or `mistral:7b` if 8b is slow

Example (Mac/Linux):
```
OLLAMA_MODEL=mistral:7b python3 server.py
```

---

## If transactions are missing

1. Check the **error report** in the portal after processing — every skipped file lists its exact reason
2. Common causes:
   - **CID-encoded PDF** (Axis Bank, sometimes Canara Robeco): Open the PDF in Mac Preview / Adobe Acrobat and "Save As" a new PDF. The text becomes readable.
   - **Password-protected PDF**: Rename the file so the password is the last segment before `.pdf`. E.g. `statement.mypass.pdf` if password is `mypass`.
   - **Ollama not running**: Check `ollama list` works in Terminal.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Connection refused: localhost:5000` in browser | Run `python3 server.py` |
| `Connection refused: localhost:11434` in server logs | Run `ollama serve` |
| Ollama returns 0 rows on new format | Try a bigger model: `ollama pull llama3.1:70b` then set `OLLAMA_MODEL=llama3.1:70b` |
| Server freezes on a big file | Ollama is slow on the first call (warm-up). Wait 90 seconds. |

---

## Contact
If you hit any issue not covered here, send the exact error message from the server Terminal window — it logs the precise tripping reason for every file.
